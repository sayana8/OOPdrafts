package streams;

import java.io.*;
import java.util.StringTokenizer;
public class testLibrary {

	public static void main(String[] args) throws Exception {
		new Library().run();
	}

}
